#include <bits/stdc++.h>

int calc(int);


int main(){
    int c,r;
    int n;
    scanf("%d", &n);

    c=calc(n);

    printf("O valor do resultado e: %d\n", c);

    return 0;

}
int calc(int N){

  int s=0,i=0;

    for(i=0;a>=1;i++){
        m*=a;
}
  return m;
}

