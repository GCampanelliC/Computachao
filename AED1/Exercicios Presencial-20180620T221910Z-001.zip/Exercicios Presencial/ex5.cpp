#include <bits/stdc++.h>

int maior(int);


int main(){
    int V[10];
    int i,ii,vetb[10];
    for(i=0;i<10;i++){
    scanf("%d", &V[i]);
    }

    vetb[10]=vetor(V[10]);

        for(ii=0;ii<10;ii++){
            printf("%d", vetb);
        }

    return 0;

}

int vet(int vetc[10]){

  int i=0,ii=0,vetd[10];

    for(i=0;i<10;i++){
        for(ii=0;ii<10;ii++){
        if(vetc[i]>0){
            vetd[ii] = vetc[i];

        }
    }
}
  return vetd[10];
}
