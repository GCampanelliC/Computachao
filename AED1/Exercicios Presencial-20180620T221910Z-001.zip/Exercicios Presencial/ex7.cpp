#include <bits/stdc++.h>

int maior(int);


int main(){
    int a[5][5];
    int l,c,mai;
    for(l=0;l<5;l++){
        for(c=0;c<5;c++){
            scanf("%d", &a[l][c]);
    }

    mai = maior(a[5][5]);

    printf("o maior elemento e : %d\n", mai);


    return 0;

}
}
int maior(int v[5][5]){

  int i=0,ii=0,ma=-99999;

    for(i=0;i<5;i++){
        for(ii=0;ii<5;ii++){
        if(v[i][ii]> ma){
            ma = v[i][ii];

        }
    }
}
  return ma;
}

