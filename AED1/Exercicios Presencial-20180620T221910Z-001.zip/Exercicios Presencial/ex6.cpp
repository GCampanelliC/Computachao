#include <bits/stdc++.h>

double verif(double, double);


int main(){
    double V[12],Y;
    int i,a;
    for(i=0;i<10;i++){
    scanf("%d", &V[i]);
    }
    scanf("%d", &Y);

    a=verif(V[12],Y);

    if(a=1){
        printf("Esta no vetor\n");
    }
    else if(a=0){
        printf("Nao esta no vetor\n");
    }

    return 0;
}

double verif(double vet[12], double B){

  int i=0,c=0;

    for(i=0;i<10;i++){

        if(vet[i]==B){
          c=1;
    }

  return c;
}
}

